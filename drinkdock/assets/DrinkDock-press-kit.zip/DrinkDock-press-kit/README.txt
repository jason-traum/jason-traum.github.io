DrinkDock press kit

Product images are design renders. The two concept visualizations show possible placements and are not customer installations.
Specifications are design targets for pilot units planned for 2027.
Media contact: drinkdockhq@gmail.com
